(function (window, document) {
    console.log('scripts');
})(window, document);
